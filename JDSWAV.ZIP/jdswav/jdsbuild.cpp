
//
//          jdslib wav library builder for judas sound system
//                   by Piotr Ulaszewski (BS/PETERS)
//                               on 28 / 11 / 2007
//                          create the jdswav.lib file
//

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>


#define MAXFILES 100           // this makes a header of 7212 bytes with current structure formats

#pragma pack(push,1)
typedef struct
{
        unsigned offset;       // offset in library for this wav entry
        unsigned size;         // size of this wav entry
        char filename[64];     // wav filename
} WAV_ENTRY;

typedef struct
{
        char logo[4];          // JDSL format sign (header has max MAXFILES wav entries)
        unsigned filescount;   // number of wav files in library
        unsigned encoding;     // encoding method
        WAV_ENTRY files[MAXFILES];  // singel wav entry
} LIB_HEADER;
#pragma pack(pop)

LIB_HEADER libheader = {0};
char outfilename[260] = {0};


int main(int argc,char *argv[])
{
    int ihandle, ohandle;

    printf ("\n");
    printf ("-----------------------------------------------------------------------\n");
    printf ("JDSBUILD WAV library builder for Judas Sound System v1.0\n");
    printf ("written by Piotr Ulaszewski on the 28th of Nov 2007 (BS)\n");
    printf ("follows Judas Sound System license.\n");
    printf ("-----------------------------------------------------------------------\n");

    // set output filename
    if (argc == 1) {
        strcpy(outfilename, "jdswav.lib");
    } else {
        strcpy(outfilename, argv[1]);     // given on command line
    }
    if (argc > 2) {
        printf("Error : Too many parameters given on command line.\n");
        exit(-1);
    }


   // ************************************************************************
   // fill in libheader
   // ************************************************************************

/*
       struct _finddata_t {
       unsigned attrib;
       time_t time_create;   // -1 for FAT file systems
       time_t time_access;  // -1 for FAT file systems
       time_t time_write;
       _fsize_t size;
       char name[_MAX_PATH];
     };
*/

    struct _finddata_t  fileinfo;
    long                handle;
    int                 thandle;
    int                 n;

    libheader.logo[0] = 'J';
    libheader.logo[1] = 'D';
    libheader.logo[2] = 'S';
    libheader.logo[3] = 'L';
    libheader.filescount = 0;
    libheader.encoding = 0;   // none atm

    handle = _findfirst ("*.wav", &fileinfo);
    if (handle == -1) {
        printf ("Error : Could not find wav files in current directory!\n");
        exit (-1);
    }

    thandle = handle;
    n = 0;
    while ((thandle != -1) && (n < MAXFILES)) {
        // update lib header with found wav file
        libheader.filescount++;
        strcpy (libheader.files[n].filename, fileinfo.name);
        if (n == 0) libheader.files[n].offset = sizeof(LIB_HEADER);   // 1st entry
        else libheader.files[n].offset = libheader.files[n - 1].offset + libheader.files[n - 1].size;   // next entries
        libheader.files[n].size = fileinfo.size;
        n++;
        thandle = _findnext (handle, &fileinfo);
    }
    _findclose (handle);


   // ************************************************************************
   // calculate output library size and add wav files to library
   // ************************************************************************

    int outsize = 0;
    unsigned char* outbuffer;

    ohandle = open (outfilename, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, S_IREAD | S_IWRITE);
    if (ohandle == -1) {
        printf ("Error : Could not create output library file!\n");
        exit (-1);
    }
    if (write (ohandle, &libheader, sizeof(LIB_HEADER)) < sizeof(LIB_HEADER)) {
        close (ohandle);
        printf ("Error : Could not write to output library file!\n");
        exit (-1);
    }
    
    for (n = 0; n < libheader.filescount; n++) {
        ihandle = open (libheader.files[n].filename, O_RDONLY | O_BINARY);
        if (ihandle == -1) {
            printf ("Error : Wav file to be added to the library does not exist anymore!\n");
            exit (-1);
        }

        // alloc memory and read
        outbuffer = (unsigned char *) malloc (sizeof(unsigned char) * (libheader.files[n].size));
        read (ihandle, outbuffer, libheader.files[n].size);

        // add to library at given offset
        if (write (ohandle, outbuffer, libheader.files[n].size) < libheader.files[n].size) {
            close (ohandle);
            printf ("Error : Could not write to output library file!\n");
            exit (-1);
        }
        
        // free temp outbuffer and close temp input handle
        free(outbuffer);
        close (ihandle);
    }
    close (ohandle);
   

   // ************************************************************************

   printf ("%s WAV library build success with %d entries.\n", outfilename, libheader.filescount);
   return 0;
}
